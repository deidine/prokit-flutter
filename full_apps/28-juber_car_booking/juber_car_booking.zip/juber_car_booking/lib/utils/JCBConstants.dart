import 'package:google_fonts/google_fonts.dart';

double jcbButtonRadius = 4.0;
double jcbBottomSheetRadius = 20.0;


var jcbFont = GoogleFonts.roboto().fontFamily;

