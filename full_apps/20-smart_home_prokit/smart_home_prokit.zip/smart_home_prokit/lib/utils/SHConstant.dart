const DeviceTypeFan = 'fan';
const DeviceTypeAC = 'ac';
const DeviceTypePurifier = 'purifier';
const DeviceTypeLight = 'light';
const LivingRoomImage =  'https://media.architecturaldigest.com/photos/571e97c5741fcddb16b559c9/master/w_1600%2Cc_limit/modernist-decor-inspiration-01.jpg';
const kitchenImage = 'https://www.eatwell101.com/wp-content/uploads/2014/01/painting-inside-of-kitchen-cabinets.jpg';
const BedRoomImage = 'https://assets-news.housing.com/news/wp-content/uploads/2020/05/04190400/17-fabulous-bedroom-decor-ideas-FB-1200x700-compressed.jpg';

const isDarkModeOnPref = 'isDarkModeOnPref';