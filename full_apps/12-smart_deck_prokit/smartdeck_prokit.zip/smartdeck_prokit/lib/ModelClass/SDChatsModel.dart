class SDChatsModel {
  String? profileImage;
  String? name;
  String? message;
  String? time;
  String? pendingMessages;

  SDChatsModel({
    this.profileImage,
    this.name,
    this.message,
    this.time,
    this.pendingMessages,
  });
}
