const RFAppName = "Room Finder";
const RFAppSubTitle = "Ultimate property Finder";
