class SneakerShoppingModel {
  String? name;
  String? subtitle;
  String? img;
  String? amount;

  SneakerShoppingModel({this.name, this.img, this.subtitle, this.amount});
}
