enum Sorting { Name, Modified }
enum AccessOption { edit, view }

const String CSAppName = "Cloudbox";
const cloud_lblDarkMode = "Dark Mode";

const BaseUrl = 'https://assets.iqonic.design/old-themeforest-images/prokit';
