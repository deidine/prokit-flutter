import 'package:cloudstorage_prokit/utils/CSConstants.dart';

const CSCloudboxLogo = "$BaseUrl/images/cloudStorage/cloudboxLogo.png";
const CSGoogleLogo = 'images/google.png';
const CSAppleLogo = 'images/apple.png';
const CSSearchImg = 'images/search_img.png';
const CSOfflineImg = 'images/offline.png';
const CSDogGIFImg = 'images/dog.gif';
const CSBookImg = 'images/book.png';
const CSFolderIcon = 'images/folder.png';
const CSDefaultImg = 'images/folder.png';
const CSFileImg = 'images/file.png';

