class MIADashboardModel{

  String image;
  String tab;


  MIADashboardModel({required this.image,required this.tab});

}