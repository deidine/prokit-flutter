import '../models/MIASelectOptionsModel.dart';

const appName = 'Mealime App';

const miaDefaultRadius = 16.0;
List<MIASelectOptionsModel> collections = [];

const isDarkModeOnPref = 'isDarkModeOnPref';
