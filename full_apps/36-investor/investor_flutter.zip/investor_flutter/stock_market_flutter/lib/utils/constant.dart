const isDarkModeOnPref = 'isDarkModeOnPref';
const String? mlEnter_code = 'Enter Authentication Code';
const String? mlAuthentication_msg = 'Enter the 5 digit code we just texted to your \nphone number. +1 567 546 4567';
const String? mlHave_no_code = 'Didn\'t receive a code?';

const int headingTextSize = 20;
