package com.iqonic.stockinvestment.stock_investment_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
