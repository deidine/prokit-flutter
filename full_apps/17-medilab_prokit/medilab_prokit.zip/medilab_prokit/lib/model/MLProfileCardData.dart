import 'dart:ui';

class MLProfileCardData {
  String? img;
  String? name;
  Color? color;

  MLProfileCardData({this.img, this.name, this.color});
}
