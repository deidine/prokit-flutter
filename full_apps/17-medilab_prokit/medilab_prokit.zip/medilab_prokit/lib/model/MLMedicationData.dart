class MLMedicationData {
  String? image;
  String? title;

  MLMedicationData({this.image, this.title});
}
