class MLOrderSuccessData {
  String? title;
  String? data;

  MLOrderSuccessData({this.title, this.data});
}
