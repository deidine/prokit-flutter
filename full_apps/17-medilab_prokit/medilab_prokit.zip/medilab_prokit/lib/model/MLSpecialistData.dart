class MLSpecialistData {
  String? image;
  String? title;
  String? subtitle;

  MLSpecialistData({this.image, this.title, this.subtitle});
}
