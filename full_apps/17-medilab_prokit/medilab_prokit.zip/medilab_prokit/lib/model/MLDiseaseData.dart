class MLDiseaseData {
  String? image;
  String? title;
  String? subtitle;

  MLDiseaseData({this.image, this.title, this.subtitle});
}
