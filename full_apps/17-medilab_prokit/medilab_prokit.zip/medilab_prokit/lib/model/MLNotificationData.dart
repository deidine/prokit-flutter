class MLNotificationData {
  String? image;
  String? title;
  String? time;
  String? status;
  String? detail;

  MLNotificationData({this.image, this.title, this.time, this.status, this.detail});
}
