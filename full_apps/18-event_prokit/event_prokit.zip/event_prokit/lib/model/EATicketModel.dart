class EATicketModel{
  String? name;
  String? time;
  String? payment;
  int? count;

  EATicketModel({this.name, this.time, this.payment, this.count});
}