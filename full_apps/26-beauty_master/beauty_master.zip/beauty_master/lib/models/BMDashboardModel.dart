class BMDashboardModel{

  String selectedIcon;
  String unSelectedIcon;

  BMDashboardModel({required this.selectedIcon,required this.unSelectedIcon});

}