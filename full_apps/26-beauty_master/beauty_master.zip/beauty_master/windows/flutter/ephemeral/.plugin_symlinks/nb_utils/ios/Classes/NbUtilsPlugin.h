#import <Flutter/Flutter.h>

@interface NbUtilsPlugin : NSObject<FlutterPlugin>
@end
