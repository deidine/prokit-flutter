package com.prokit.beauty_master

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
