class WalkThroughModel {
  String title;
  String subTitle;
  String imagePath;

  WalkThroughModel(this.title, this.subTitle, this.imagePath);
}
