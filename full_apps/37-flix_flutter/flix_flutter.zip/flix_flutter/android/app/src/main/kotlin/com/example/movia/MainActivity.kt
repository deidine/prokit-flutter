package com.example.movia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
