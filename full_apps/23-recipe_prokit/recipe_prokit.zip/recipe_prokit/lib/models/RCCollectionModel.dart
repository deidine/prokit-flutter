class RCCollectionModel{

  String name;
  String image;
  String numberOfPosts;
  bool selected;

  RCCollectionModel({required this.name,required this.image,required this.numberOfPosts,required this.selected});

}