package com.example.carea

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
