package com.nb.nb_utils_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
