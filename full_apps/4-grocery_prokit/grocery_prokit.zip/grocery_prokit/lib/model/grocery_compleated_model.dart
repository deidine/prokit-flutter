class Compleated {
  var orderDate;
  var orderAmount;
  var totelItem;

  Compleated({this.orderDate, this.orderAmount, this.totelItem});
}

List<Compleated> compleated = [
  Compleated(
    orderDate: '6 April 2020',
    orderAmount: '1820.00',
    totelItem: '04',
  ),
  Compleated(
    orderDate: '30 March 2020',
    orderAmount: '5300.00',
    totelItem: '15',
  )
];
