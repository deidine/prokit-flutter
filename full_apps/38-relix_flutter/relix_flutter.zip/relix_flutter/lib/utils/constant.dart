const APP_NAME = 'Relix';
const DEFAULT_RADIUS = 30.0;
