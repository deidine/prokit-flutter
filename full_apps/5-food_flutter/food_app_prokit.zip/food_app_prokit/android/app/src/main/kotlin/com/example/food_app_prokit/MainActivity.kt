package com.example.food_app_prokit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
