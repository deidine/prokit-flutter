#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/home/gmits/snap/flutter/common/flutter"
export "FLUTTER_APPLICATION_PATH=/home/gmits/Documents/prokit_full_app_zip_code/full_apps/35-ev_spot/ev_spot_flutter"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=2.0.0"
export "FLUTTER_BUILD_NUMBER=2.0.0"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
