class SpeedCB {
  String? speedCBTitle;
  bool isSpeedChecked = false;

  SpeedCB({required this.speedCBTitle});
}
