const APP_NAME = 'EV SPOT';
const DEFAULT_RADIUS = 10.0;

const COMPANY_TERMS =
    'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\`s standard dummy text ever sine 1500s, when an unknown printer took a gallery type and scrambled it to make a type specimen book.';
const TERMS_CONDITIONS =
    'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.';
