package com.example.musicpodcast_prokit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
